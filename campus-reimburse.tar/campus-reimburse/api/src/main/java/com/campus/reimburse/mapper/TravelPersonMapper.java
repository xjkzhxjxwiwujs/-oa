package com.campus.reimburse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.reimburse.domain.TravelPerson;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TravelPersonMapper extends BaseMapper<TravelPerson> {
}
