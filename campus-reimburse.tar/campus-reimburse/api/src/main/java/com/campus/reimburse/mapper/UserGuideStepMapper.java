package com.campus.reimburse.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.campus.reimburse.domain.UserGuideStep;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserGuideStepMapper extends BaseMapper<UserGuideStep> {
}
