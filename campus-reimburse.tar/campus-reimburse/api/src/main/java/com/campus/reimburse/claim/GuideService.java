package com.campus.reimburse.claim;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.campus.reimburse.common.LoginUser;
import com.campus.reimburse.common.SecurityUtils;
import com.campus.reimburse.domain.UserGuideProgress;
import com.campus.reimburse.mapper.UserGuideProgressMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class GuideService {
    private final UserGuideProgressMapper progressMapper;

    public static final List<String> FEATURES = List.of(
            "travel.apply.create", "travel.claim.create", "claim.timeline",
            "claim.return_resubmit", "approval.dept", "approval.college",
            "approval.finance", "data.export.finance", "pdf.import.claim");

    public Map<String, Object> list() {
        LoginUser me = SecurityUtils.requireUser();
        List<UserGuideProgress> rows = progressMapper.selectList(
                new LambdaQueryWrapper<UserGuideProgress>().eq(UserGuideProgress::getUserId, me.getId()));
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("features", FEATURES);
        m.put("progress", rows);
        return m;
    }

    public void start(String featureKey) {
        upsert(featureKey, "IN_PROGRESS", false);
    }

    public void skip(String featureKey) {
        upsert(featureKey, "SKIPPED", false);
    }

    public void complete(String featureKey) {
        upsert(featureKey, "COMPLETED", true);
    }

    private void upsert(String feature, String status, boolean done) {
        LoginUser me = SecurityUtils.requireUser();
        UserGuideProgress p = progressMapper.selectOne(new LambdaQueryWrapper<UserGuideProgress>()
                .eq(UserGuideProgress::getUserId, me.getId())
                .eq(UserGuideProgress::getFeatureKey, feature)
                .eq(UserGuideProgress::getGuideVersion, 1)
                .last("LIMIT 1"));
        if (p == null) {
            p = new UserGuideProgress();
            p.setUserId(me.getId());
            p.setFeatureKey(feature);
            p.setGuideVersion(1);
            p.setRunId(UUID.randomUUID().toString());
            p.setRowVersion(0);
            p.setFirstStartedAt(LocalDateTime.now());
            p.setStatus(status);
            if (done) {
                p.setCompletedAt(LocalDateTime.now());
            }
            if ("SKIPPED".equals(status)) {
                p.setSkippedAt(LocalDateTime.now());
            }
            progressMapper.insert(p);
        } else {
            p.setStatus(status);
            p.setRowVersion(p.getRowVersion() + 1);
            if (done) {
                p.setCompletedAt(LocalDateTime.now());
            }
            if ("SKIPPED".equals(status)) {
                p.setSkippedAt(LocalDateTime.now());
            }
            progressMapper.updateById(p);
        }
    }
}
