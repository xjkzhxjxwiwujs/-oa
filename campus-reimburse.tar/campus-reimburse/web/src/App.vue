<template>
  <div v-if="isLogin" class="login-wrap"><router-view /></div>
  <div v-else class="shell">
    <aside class="side">
      <h1>智汇签</h1>
      <template v-if="showApply">
        <router-link to="/apply/home">申请人工作台</router-link>
        <router-link to="/apply/travel-apply">出差申请</router-link>
        <router-link to="/apply/travel-claim">差旅报销</router-link>
        <router-link to="/apply/docs">我的单据</router-link>
      </template>
      <template v-if="showApprove">
        <router-link to="/approve/home">审批工作台</router-link>
        <router-link v-if="canFinance" to="/approve/finance">财务查询/导出</router-link>
      </template>
      <router-link to="/help">帮助与引导</router-link>
      <div style="margin:16px;font-size:12px;opacity:.8">{{ user?.realName }} · {{ user?.roles?.join(',') }}</div>
      <a href="#" @click.prevent="onLogout" style="margin:0 16px">退出</a>
    </aside>
    <main class="main"><router-view /></main>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuth } from './stores'

const route = useRoute()
const router = useRouter()
const auth = useAuth()
const user = computed(() => auth.user)
const isLogin = computed(() => route.path === '/login')
const showApply = computed(() => user.value?.roles?.includes('APPLICANT'))
const showApprove = computed(() =>
  user.value?.roles?.some((x) => ['APPROVER', 'COLLEGE', 'FINANCE', 'ADMIN'].includes(x))
)
const canFinance = computed(() => user.value?.roles?.includes('FINANCE') || user.value?.roles?.includes('ADMIN'))

async function onLogout() {
  await auth.logout()
  router.push('/login')
}
</script>
