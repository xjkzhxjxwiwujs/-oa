<template>
  <div class="card">
    <h2>申请人工作台</h2>
    <p class="muted">先填出差申请（无金额），学院通过后再填差旅报销。</p>
    <el-alert title="OCR 识别与验真放在二期。本期请手工填写发票。" type="info" show-icon style="margin:12px 0" />
    <div style="display:flex;gap:12px;flex-wrap:wrap">
      <el-button id="btn-new-apply" type="primary" @click="$router.push('/apply/travel-apply')">新建出差申请</el-button>
      <el-button id="btn-new-claim" @click="$router.push('/apply/travel-claim')">新建差旅报销</el-button>
      <el-button @click="$router.push('/help')">新手引导</el-button>
    </div>
  </div>
  <div class="card" v-if="notifies.length">
    <h3>通知</h3>
    <el-timeline>
      <el-timeline-item v-for="n in notifies" :key="n.id" :timestamp="n.createdAt">{{ n.title }} · {{ n.content }}</el-timeline-item>
    </el-timeline>
  </div>
  <div class="card">
    <h3>我的单据</h3>
    <el-table :data="rows" @row-click="open">
      <el-table-column prop="claimNo" label="单号" width="180" />
      <el-table-column prop="claimType" label="类型" width="140">
        <template #default="{ row }">{{ row.claimType === 'TRAVEL_APPLY' ? '出差申请' : '差旅报销' }}</template>
      </el-table-column>
      <el-table-column prop="reason" label="事由" />
      <el-table-column prop="status" label="状态" width="120" />
      <el-table-column prop="currentAssigneeName" label="当前处理人" width="120" />
      <el-table-column prop="amount" label="金额" width="100" />
    </el-table>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import http from '../../api'

const rows = ref<any[]>([])
const notifies = ref<any[]>([])
const router = useRouter()
onMounted(async () => {
  rows.value = (await http.get('/api/applicant/claims')).data.data || []
  notifies.value = (await http.get('/api/common/notifies')).data.data || []
})
function open(row: any) {
  const p = row.claimType === 'TRAVEL_APPLY' ? '/apply/travel-apply/' : '/apply/travel-claim/'
  router.push(p + row.id)
}
</script>
