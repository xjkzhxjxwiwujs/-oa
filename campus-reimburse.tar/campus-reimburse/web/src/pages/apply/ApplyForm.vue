<template>
  <div class="card">
    <h2>{{ id ? '出差申请' : '新建出差申请' }}</h2>
    <p class="muted">不填金额。审批路径：部门领导 → 学院。通过后才能报销。</p>
    <el-alert v-if="detail?.lastReturn" :title="'最近退回：' + detail.lastReturn.comment" type="warning" show-icon style="margin-bottom:12px" />
    <el-form label-width="110px">
      <el-form-item label="经费项目">
        <el-select v-model="form.projectId" :disabled="readonly" placeholder="选择项目代码" style="width:360px">
          <el-option v-for="p in projects" :key="p.id" :label="p.code + ' ' + p.name" :value="p.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="出差原因"><el-input v-model="form.reason" maxlength="200" show-word-limit :disabled="readonly" /></el-form-item>
      <el-form-item label="开始日期"><el-date-picker v-model="form.startDate" value-format="YYYY-MM-DD" :disabled="readonly" /></el-form-item>
      <el-form-item label="结束日期"><el-date-picker v-model="form.endDate" value-format="YYYY-MM-DD" :disabled="readonly" /></el-form-item>
      <el-form-item label="备注"><el-input v-model="form.remark" type="textarea" :disabled="readonly" /></el-form-item>
      <h3>出差人</h3>
      <el-button v-if="!readonly" size="small" @click="form.persons.push({ personType: 'STAFF', isApplicant: 0, guestName: '' })">添加</el-button>
      <el-table :data="form.persons" style="margin:8px 0 16px">
        <el-table-column label="类型" width="140">
          <template #default="{ row }">
            <el-select v-model="row.personType" :disabled="readonly">
              <el-option v-for="d in personTypes" :key="d.dictCode" :label="d.dictLabel" :value="d.dictCode" />
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="编外姓名">
          <template #default="{ row }"><el-input v-model="row.guestName" :disabled="readonly || row.isApplicant === 1" /></template>
        </el-table-column>
        <el-table-column label="申请人本人" width="120">
          <template #default="{ row }"><el-switch v-model="row.isApplicant" :active-value="1" :inactive-value="0" :disabled="readonly" /></template>
        </el-table-column>
        <el-table-column v-if="!readonly" width="80">
          <template #default="{ $index }"><el-button link type="danger" @click="form.persons.splice($index,1)">删</el-button></template>
        </el-table-column>
      </el-table>
      <h3>行程</h3>
      <el-button v-if="!readonly" size="small" @click="form.legs.push({ fromPlace: '', toPlace: '', transportCode: 'HSR', departDate: form.startDate })">添加</el-button>
      <el-table :data="form.legs" style="margin:8px 0 16px">
        <el-table-column label="出发"><template #default="{ row }"><el-input v-model="row.fromPlace" :disabled="readonly" /></template></el-table-column>
        <el-table-column label="到达"><template #default="{ row }"><el-input v-model="row.toPlace" :disabled="readonly" /></template></el-table-column>
        <el-table-column label="交通" width="140">
          <template #default="{ row }">
            <el-select v-model="row.transportCode" :disabled="readonly">
              <el-option v-for="d in transports" :key="d.dictCode" :label="d.dictLabel" :value="d.dictCode" />
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="出发日" width="180">
          <template #default="{ row }"><el-date-picker v-model="row.departDate" value-format="YYYY-MM-DD" :disabled="readonly" /></template>
        </el-table-column>
        <el-table-column v-if="!readonly" width="80">
          <template #default="{ $index }"><el-button link type="danger" @click="form.legs.splice($index,1)">删</el-button></template>
        </el-table-column>
      </el-table>
      <el-form-item v-if="!readonly">
        <el-button @click="save">保存草稿</el-button>
        <el-button type="primary" @click="submit">提交审批</el-button>
      </el-form-item>
      <el-form-item v-else>
        <el-button @click="pdf">导出 PDF</el-button>
      </el-form-item>
    </el-form>
  </div>
  <div class="card">
    <h3>将到达的审批人</h3>
    <p class="muted" v-if="!preview.length">保存前也可预览，提交时系统按部门和角色指定，不能自选。</p>
    <el-descriptions :column="2" border>
      <el-descriptions-item v-for="p in preview" :key="p.nodeCode" :label="p.nodeName">{{ p.realName }}</el-descriptions-item>
    </el-descriptions>
  </div>
  <div class="card" v-if="id">
    <h3>进度</h3>
    <Timeline :nodes="nodes" />
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import http, { download } from '../../api'
import Timeline from '../../components/Timeline.vue'
import { useAuth } from '../../stores'

const route = useRoute()
const router = useRouter()
const auth = useAuth()
const id = computed(() => (route.params.id as string) || '')
const form = reactive<any>({
  projectId: undefined,
  reason: '',
  startDate: '',
  endDate: '',
  remark: '',
  persons: [{ personType: 'STAFF', isApplicant: 1, guestName: '' }],
  legs: [{ fromPlace: '', toPlace: '', transportCode: 'HSR', departDate: '' }]
})
const detail = ref<any>()
const nodes = ref<any[]>([])
const preview = ref<any[]>([])
const projects = ref<any[]>([])
const transports = ref<any[]>([])
const personTypes = ref<any[]>([])
const readonly = computed(() => {
  const s = detail.value?.form?.status
  return !!s && s !== 'DRAFT' && s !== 'RETURNED'
})

async function loadMeta() {
  projects.value = (await http.get('/api/common/projects')).data.data || []
  const dicts = (await http.get('/api/common/dicts')).data.data || []
  transports.value = dicts.filter((d: any) => d.dictType === 'TRANSPORT')
  personTypes.value = dicts.filter((d: any) => d.dictType === 'PERSON_TYPE')
  preview.value = (await http.get('/api/applicant/approver-preview', { params: { claimType: 'TRAVEL_APPLY' } })).data.data || []
}
async function load(forceId?: string) {
  await loadMeta()
  const cid = forceId || id.value
  if (!cid) return
  const d = (await http.get(`/api/applicant/travel-applies/${cid}`)).data.data
  detail.value = d
  if (d.apply) {
    form.projectId = d.apply.projectId
    form.reason = d.apply.reason
    form.startDate = d.apply.startDate
    form.endDate = d.apply.endDate
    form.remark = d.apply.remark
  }
  form.persons = (d.persons || []).map((p: any) => ({ ...p }))
  form.legs = (d.legs || []).map((l: any) => ({ ...l }))
  nodes.value = d.timeline || []
}
onMounted(load)

async function save() {
  const { data } = await http.post('/api/applicant/travel-applies', { ...form, id: id.value || undefined })
  ElMessage.success('已保存')
  await http.post('/api/me/guides/travel.apply.create/complete').catch(() => {})
  if (!id.value) router.replace('/apply/travel-apply/' + data.data.id)
  else await load()
  return data.data.id as number
}
async function submit() {
  const cid = await save()
  await http.post(`/api/applicant/travel-applies/${cid}/submit`, { version: detail.value?.form?.version })
  ElMessage.success('已提交')
  router.replace('/apply/travel-apply/' + cid)
  await load(String(cid))
}
async function pdf() {
  await download('/api/applicant/pdf/export', (detail.value?.form?.claimNo || 'apply') + '.pdf', { method: 'GET', params: { id: id.value } })
}
</script>
