<template>
  <div class="card">
    <h2>{{ id ? '差旅报销' : '新建差旅报销' }}</h2>
    <p class="muted">必须关联已通过的出差申请。行程与人员只读来自申请单，本期只填费用和票据。</p>
    <el-alert v-if="detail?.lastReturn" :title="'最近退回：' + detail.lastReturn.comment" type="warning" show-icon style="margin-bottom:12px" />
    <el-form label-width="120px">
      <el-form-item label="关联申请">
        <el-select v-model="form.sourceApplyId" :disabled="readonly || !!id" placeholder="选择已通过的出差申请" style="width:420px" @change="onApplyChange">
          <el-option v-for="a in applies" :key="a.id" :label="a.claimNo + ' ' + (a.reason || '')" :value="a.id" />
        </el-select>
      </el-form-item>
      <div v-if="source" class="card" style="background:#f8fbff">
        <h3>申请单信息（只读）</h3>
        <p>项目：{{ source.projectCode }} {{ source.projectName }}</p>
        <p>原因：{{ source.apply?.reason }} · {{ source.apply?.startDate }} 至 {{ source.apply?.endDate }}</p>
        <p>人员：{{ (source.persons || []).map((p: any) => p.guestName || '本人').join('、') }}</p>
        <p>行程：{{ (source.legs || []).map((l: any) => l.fromPlace + '→' + l.toPlace).join('；') }}</p>
        <h4>申请已走完的审批</h4>
        <Timeline :nodes="applyTimeline" />
      </div>
      <el-form-item label="收款银行"><el-input v-model="form.payeeBank" :disabled="readonly" /></el-form-item>
      <el-form-item label="收款账号"><el-input v-model="form.payeeAccount" :disabled="readonly" :placeholder="detail?.payeeAccountMasked || ''" /></el-form-item>
      <h3>费用明细</h3>
      <el-button v-if="!readonly" size="small" @click="form.expenses.push({ expenseTypeCode: 'TRAFFIC', occurredOn: '', amount: 0, remark: '' })">添加</el-button>
      <el-table :data="form.expenses" style="margin:8px 0 16px">
        <el-table-column label="类型" width="140">
          <template #default="{ row }">
            <el-select v-model="row.expenseTypeCode" :disabled="readonly">
              <el-option v-for="d in expenses" :key="d.dictCode" :label="d.dictLabel" :value="d.dictCode" />
            </el-select>
          </template>
        </el-table-column>
        <el-table-column label="发生日" width="180">
          <template #default="{ row }"><el-date-picker v-model="row.occurredOn" value-format="YYYY-MM-DD" :disabled="readonly" /></template>
        </el-table-column>
        <el-table-column label="金额">
          <template #default="{ row }"><el-input-number v-model="row.amount" :min="0.01" :precision="2" :disabled="readonly" /></template>
        </el-table-column>
        <el-table-column label="说明"><template #default="{ row }"><el-input v-model="row.remark" :disabled="readonly" /></template></el-table-column>
        <el-table-column v-if="!readonly" width="80">
          <template #default="{ $index }"><el-button link type="danger" @click="form.expenses.splice($index,1)">删</el-button></template>
        </el-table-column>
      </el-table>
      <h3>发票（手工填写）</h3>
      <el-upload v-if="!readonly && id" :show-file-list="false" :http-request="uploadInvoice">
        <el-button size="small">上传发票图片/PDF</el-button>
      </el-upload>
      <p v-else-if="!readonly" class="muted">请先保存草稿再上传发票。</p>
      <el-table :data="form.invoices" style="margin:8px 0 16px">
        <el-table-column prop="fileId" label="文件ID" width="90" />
        <el-table-column label="票号"><template #default="{ row }"><el-input v-model="row.invoiceNo" :disabled="readonly" /></template></el-table-column>
        <el-table-column label="代码"><template #default="{ row }"><el-input v-model="row.invoiceCode" :disabled="readonly" /></template></el-table-column>
        <el-table-column label="金额" width="140">
          <template #default="{ row }"><el-input-number v-model="row.amount" :min="0.01" :precision="2" :disabled="readonly" /></template>
        </el-table-column>
        <el-table-column label="开票日" width="180">
          <template #default="{ row }"><el-date-picker v-model="row.issueDate" value-format="YYYY-MM-DD" :disabled="readonly" /></template>
        </el-table-column>
      </el-table>
      <el-form-item label="报销单 PDF" v-if="id">
        <el-upload v-if="!readonly || canFinance" :show-file-list="false" accept=".pdf" :http-request="importPdf">
          <el-button>导入报销单 PDF（不解析费用）</el-button>
        </el-upload>
        <el-button style="margin-left:8px" @click="exportPdf">导出 PDF</el-button>
      </el-form-item>
      <el-form-item v-if="!readonly">
        <el-button @click="save">保存草稿</el-button>
        <el-button type="primary" @click="submit">提交审批</el-button>
      </el-form-item>
    </el-form>
  </div>
  <div class="card" v-if="id">
    <h3>报销进度</h3>
    <Timeline :nodes="nodes" />
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import http, { download } from '../../api'
import Timeline from '../../components/Timeline.vue'
import { useAuth } from '../../stores'

const route = useRoute()
const router = useRouter()
const auth = useAuth()
const id = computed(() => (route.params.id as string) || '')
const form = reactive<any>({
  sourceApplyId: undefined,
  payeeBank: '',
  payeeAccount: '',
  expenses: [{ expenseTypeCode: 'TRAFFIC', occurredOn: '', amount: 0.01, remark: '' }],
  invoices: [] as any[]
})
const detail = ref<any>()
const source = ref<any>()
const applies = ref<any[]>([])
const expenses = ref<any[]>([])
const nodes = ref<any[]>([])
const applyTimeline = ref<any[]>([])
const canFinance = computed(() => auth.user?.roles?.includes('FINANCE'))
const readonly = computed(() => {
  const s = detail.value?.form?.status
  return !!s && s !== 'DRAFT' && s !== 'RETURNED'
})

async function loadMeta() {
  const all = (await http.get('/api/applicant/travel-applies')).data.data || []
  applies.value = all.filter((x: any) => x.status === 'APPROVED')
  const dicts = (await http.get('/api/common/dicts')).data.data || []
  expenses.value = dicts.filter((d: any) => d.dictType === 'EXPENSE_TYPE')
}
async function load(forceId?: string) {
  await loadMeta()
  const cid = forceId || id.value
  if (!cid) return
  const d = (await http.get(`/api/applicant/travel-claims/${cid}`)).data.data
  detail.value = d
  form.sourceApplyId = d.form?.sourceApplyId
  form.payeeBank = d.payeeBank
  form.expenses = (d.expenses || []).map((e: any) => ({ ...e }))
  form.invoices = (d.invoices || []).map((i: any) => ({ ...i }))
  source.value = d.sourceApply
  nodes.value = d.timeline || []
  applyTimeline.value = d.applyTimeline || []
}
onMounted(load)

async function onApplyChange() {
  if (!form.sourceApplyId) return
  const d = (await http.get(`/api/applicant/travel-applies/${form.sourceApplyId}`)).data.data
  source.value = { apply: d.apply, projectCode: d.projectCode, projectName: d.projectName, persons: d.persons, legs: d.legs }
  applyTimeline.value = d.timeline || []
}

async function save() {
  const { data } = await http.post('/api/applicant/travel-claims', { ...form, id: id.value || undefined })
  ElMessage.success('已保存')
  await http.post('/api/me/guides/travel.claim.create/complete').catch(() => {})
  if (!id.value) router.replace('/apply/travel-claim/' + data.data.id)
  else await load()
  return data.data.id as number
}
async function submit() {
  const cid = await save()
  await http.post(`/api/applicant/travel-claims/${cid}/submit`, { version: detail.value?.form?.version })
  ElMessage.success('已提交')
  router.replace('/apply/travel-claim/' + cid)
  await load(String(cid))
}
async function uploadInvoice(opt: any) {
  const fd = new FormData()
  fd.append('file', opt.file)
  fd.append('claimId', id.value)
  fd.append('materialCode', 'INVOICE')
  const { data } = await http.post('/api/applicant/files', fd)
  form.invoices.push({
    fileId: data.data.id,
    invoiceType: 'VAT',
    invoiceCode: '',
    invoiceNo: '',
    amount: 0.01,
    issueDate: ''
  })
  ElMessage.success('已上传，请补全票号')
}
async function importPdf(opt: any) {
  const fd = new FormData()
  fd.append('file', opt.file)
  fd.append('claimId', id.value)
  await http.post('/api/applicant/pdf/import', fd)
  ElMessage.success('已导入报销单 PDF')
  await http.post('/api/me/guides/pdf.import.claim/complete').catch(() => {})
}
async function exportPdf() {
  await download('/api/applicant/pdf/export', (detail.value?.form?.claimNo || 'claim') + '.pdf', { method: 'GET', params: { id: id.value } })
}
</script>
