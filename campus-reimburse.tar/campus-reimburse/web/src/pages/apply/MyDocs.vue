<template>
  <div class="card">
    <h2>我的单据</h2>
    <el-table :data="rows">
      <el-table-column prop="claimNo" label="单号" width="180" />
      <el-table-column prop="claimType" label="类型" width="140">
        <template #default="{ row }">{{ row.claimType === 'TRAVEL_APPLY' ? '出差申请' : '差旅报销' }}</template>
      </el-table-column>
      <el-table-column prop="reason" label="事由" />
      <el-table-column prop="status" label="状态" width="120" />
      <el-table-column prop="currentNode" label="当前节点" width="120" />
      <el-table-column prop="currentAssigneeName" label="处理人" width="120" />
      <el-table-column label="操作" width="120">
        <template #default="{ row }">
          <el-button link type="primary" @click="open(row)">打开</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import http from '../../api'

const rows = ref<any[]>([])
const router = useRouter()
onMounted(async () => {
  rows.value = (await http.get('/api/applicant/claims')).data.data || []
})
function open(row: any) {
  router.push((row.claimType === 'TRAVEL_APPLY' ? '/apply/travel-apply/' : '/apply/travel-claim/') + row.id)
}
</script>
