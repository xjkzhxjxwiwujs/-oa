<template>
  <div class="card">
    <h2>帮助与新手引导</h2>
    <p class="muted">引导只记录是否看过，不改业务状态。OCR / 验真正式入口在二期。</p>
    <el-button type="primary" @click="startTour">开始页面导览</el-button>
    <el-table :data="items" style="margin-top:16px">
      <el-table-column prop="label" label="功能" />
      <el-table-column prop="status" label="进度" width="140" />
      <el-table-column label="操作" width="220">
        <template #default="{ row }">
          <el-button size="small" @click="mark(row.key, 'start')">开始</el-button>
          <el-button size="small" @click="mark(row.key, 'skip')">跳过</el-button>
          <el-button size="small" type="primary" @click="mark(row.key, 'complete')">完成</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
  <el-tour v-model="tourOpen">
    <el-tour-step title="出差申请" description="出发前填写，无金额，领导→学院。" />
    <el-tour-step title="差旅报销" description="申请通过后回来一次性核算费用和发票。" />
    <el-tour-step title="进度" description="列表和详情都能看到当前节点、处理人和是否超时。" />
    <el-tour-step title="退回重提" description="退回意见会置顶，改完可再提交。" />
  </el-tour>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import http from '../api'

const LABELS: Record<string, string> = {
  'travel.apply.create': '新建出差申请',
  'travel.claim.create': '新建差旅报销',
  'claim.timeline': '查看审批进度',
  'claim.return_resubmit': '退回后重提',
  'approval.dept': '部门领导审批',
  'approval.college': '学院审批',
  'approval.finance': '财务核票终审',
  'data.export.finance': '财务导出 Excel/CSV/JSON',
  'pdf.import.claim': '导入报销单 PDF'
}

const raw = ref<any>({ features: [], progress: [] })
const tourOpen = ref(false)
const items = computed(() =>
  (raw.value.features || []).map((k: string) => {
    const p = (raw.value.progress || []).find((x: any) => x.featureKey === k)
    return { key: k, label: LABELS[k] || k, status: p?.status || '未开始' }
  })
)

async function load() {
  raw.value = (await http.get('/api/me/guides')).data.data || { features: [], progress: [] }
}
onMounted(load)
function startTour() {
  tourOpen.value = true
  http.post('/api/me/guides/claim.timeline/start').catch(() => {})
}
async function mark(key: string, act: string) {
  await http.post(`/api/me/guides/${key}/${act}`)
  await load()
}
</script>
