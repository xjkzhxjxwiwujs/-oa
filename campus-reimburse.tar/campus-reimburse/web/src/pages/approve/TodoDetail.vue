<template>
  <div class="card" v-if="detail">
    <h2>待办 {{ detail.form?.claimNo }}</h2>
    <p>{{ detail.form?.claimType === 'TRAVEL_APPLY' ? '出差申请' : '差旅报销' }} · 申请人 {{ detail.applicantName }} · 状态 {{ detail.form?.status }}</p>
    <el-alert v-if="detail.lastReturn" :title="'最近退回：' + detail.lastReturn.comment" type="warning" show-icon style="margin:8px 0" />
    <div v-if="detail.apply">
      <p>项目 {{ detail.projectCode }} {{ detail.projectName }}</p>
      <p>原因 {{ detail.apply.reason }} · {{ detail.apply.startDate }} 至 {{ detail.apply.endDate }}</p>
      <p>人员 {{ (detail.persons || []).map((p: any) => p.guestName || '教职工').join('、') }}</p>
      <p>行程 {{ (detail.legs || []).map((l: any) => l.fromPlace + '→' + l.toPlace + ' ' + (l.transportLabel || '')).join('；') }}</p>
    </div>
    <div v-if="detail.expenses">
      <p>关联申请信息见下方进度。金额合计：{{ detail.form?.amount }}</p>
      <el-table :data="detail.expenses">
        <el-table-column prop="expenseTypeCode" label="费用类型" />
        <el-table-column prop="occurredOn" label="发生日" />
        <el-table-column prop="amount" label="金额" />
        <el-table-column prop="remark" label="说明" />
      </el-table>
      <h3>发票</h3>
      <el-table :data="detail.invoices">
        <el-table-column prop="invoiceNo" label="票号" />
        <el-table-column prop="invoiceCode" label="代码" />
        <el-table-column prop="amount" label="金额" />
        <el-table-column prop="confirmStatus" label="确认" />
        <el-table-column v-if="isFinance" label="核票" width="120">
          <template #default="{ row }">
            <el-button v-if="row.confirmStatus !== 'CONFIRMED'" size="small" type="primary" @click="confirm(row.id)">确认占用</el-button>
            <span v-else>已占用</span>
          </template>
        </el-table-column>
      </el-table>
      <el-button @click="pdf">导出 PDF</el-button>
    </div>
    <h3>进度</h3>
    <Timeline :nodes="detail.timeline || []" />
    <div v-if="detail.applyTimeline">
      <h4>关联申请进度</h4>
      <Timeline :nodes="detail.applyTimeline" />
    </div>
    <el-input v-model="comment" type="textarea" placeholder="审批意见（退回/驳回必填）" style="margin:12px 0" />
    <el-button type="success" @click="act('pass')">通过</el-button>
    <el-button type="warning" @click="act('return')">退回</el-button>
    <el-button type="danger" @click="act('reject')">驳回</el-button>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import http, { download } from '../../api'
import Timeline from '../../components/Timeline.vue'
import { useAuth } from '../../stores'

const route = useRoute()
const router = useRouter()
const auth = useAuth()
const detail = ref<any>()
const comment = ref('')
const isFinance = computed(() => auth.user?.roles?.includes('FINANCE') && detail.value?.form?.currentNode === 'FINANCE')

async function load() {
  detail.value = (await http.get(`/api/approval/todos/${route.params.id}`)).data.data
  const key = detail.value?.form?.claimType === 'TRAVEL_APPLY'
    ? (detail.value.form?.currentNode === 'COLLEGE' ? 'approval.college' : 'approval.dept')
    : (detail.value.form?.currentNode === 'FINANCE' ? 'approval.finance' : 'approval.dept')
  await http.post(`/api/me/guides/${key}/start`).catch(() => {})
}
onMounted(load)

async function act(kind: string) {
  await http.post(`/api/approval/todos/${route.params.id}/${kind}`, {
    comment: comment.value,
    version: detail.value.form.version
  })
  ElMessage.success('已处理')
  await http.post(`/api/me/guides/${detail.value.form.currentNode === 'FINANCE' ? 'approval.finance' : detail.value.form.currentNode === 'COLLEGE' ? 'approval.college' : 'approval.dept'}/complete`).catch(() => {})
  router.push('/approve/home')
}
async function confirm(invoiceId: number) {
  await http.post(`/api/finance/claims/${detail.value.form.id}/invoices/${invoiceId}/confirm`)
  ElMessage.success('已确认占用')
  await load()
}
async function pdf() {
  await download('/api/finance/pdf/export', detail.value.form.claimNo + '.pdf', { method: 'GET', params: { id: detail.value.form.id } })
}
</script>
