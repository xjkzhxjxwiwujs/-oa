<template>
  <div class="card">
    <h2>审批工作台</h2>
    <p class="muted">超时待办置顶。处理人由系统按部门与角色指定，禁止自批。</p>
    <el-table :data="rows" @row-click="open">
      <el-table-column prop="claimNo" label="单号" width="180" />
      <el-table-column prop="claimType" label="类型" width="140">
        <template #default="{ row }">{{ row.claimType === 'TRAVEL_APPLY' ? '出差申请' : '差旅报销' }}</template>
      </el-table-column>
      <el-table-column prop="applicantName" label="申请人" width="120" />
      <el-table-column prop="reason" label="事由" />
      <el-table-column prop="currentNode" label="节点" width="120" />
      <el-table-column label="超时" width="80">
        <template #default="{ row }"><el-tag v-if="row.timeout" type="danger">超时</el-tag></template>
      </el-table-column>
    </el-table>
  </div>
  <div class="card" v-if="notifies.length">
    <h3>通知</h3>
    <el-timeline>
      <el-timeline-item v-for="n in notifies" :key="n.id" :timestamp="n.createdAt">{{ n.title }}</el-timeline-item>
    </el-timeline>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import http from '../../api'

const rows = ref<any[]>([])
const notifies = ref<any[]>([])
const router = useRouter()
onMounted(async () => {
  rows.value = (await http.get('/api/approval/todos')).data.data || []
  notifies.value = (await http.get('/api/common/notifies')).data.data || []
})
function open(row: any) {
  router.push('/approve/todo/' + row.todoId)
}
</script>
