<template>
  <div class="card">
    <h2>财务查询 / 导出</h2>
    <p class="muted">同一筛选，导出 Excel / CSV / JSON 列一致。</p>
    <el-button type="primary" @click="exp('xlsx')">导出 Excel</el-button>
    <el-button @click="exp('csv')">导出 CSV</el-button>
    <el-button @click="exp('json')">导出 JSON</el-button>
    <el-table :data="rows" style="margin-top:16px" @row-click="open">
      <el-table-column prop="claimNo" label="单号" width="180" />
      <el-table-column prop="applicantName" label="申请人" width="120" />
      <el-table-column prop="status" label="状态" width="120" />
      <el-table-column prop="currentNode" label="节点" width="120" />
      <el-table-column prop="amount" label="金额" width="100" />
      <el-table-column prop="createdAt" label="创建时间" />
    </el-table>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import http, { download } from '../../api'

const rows = ref<any[]>([])
const router = useRouter()
onMounted(async () => {
  rows.value = (await http.get('/api/finance/claims')).data.data || []
})
function open(row: any) {
  router.push('/approve/finance/' + row.id)
}
async function exp(format: string) {
  await download('/api/finance/export?format=' + format, 'finance.' + format, { method: 'POST' })
  await http.post('/api/me/guides/data.export.finance/complete').catch(() => {})
}
</script>
