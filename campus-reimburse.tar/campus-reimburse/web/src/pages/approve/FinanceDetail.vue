<template>
  <div class="card" v-if="detail">
    <h2>报销单 {{ detail.form?.claimNo }}</h2>
    <p>申请人 {{ detail.applicantName }} · {{ detail.form?.status }} · 金额 {{ detail.form?.amount }}</p>
    <el-table :data="detail.expenses">
      <el-table-column prop="expenseTypeCode" label="类型" />
      <el-table-column prop="occurredOn" label="日期" />
      <el-table-column prop="amount" label="金额" />
    </el-table>
    <h3>发票</h3>
    <el-table :data="detail.invoices">
      <el-table-column prop="invoiceNo" label="票号" />
      <el-table-column prop="confirmStatus" label="确认" />
      <el-table-column label="操作" width="140">
        <template #default="{ row }">
          <el-button v-if="row.confirmStatus !== 'CONFIRMED' && detail.form?.currentNode === 'FINANCE'" size="small" @click="confirm(row.id)">确认占用</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-upload :show-file-list="false" accept=".pdf" :http-request="importPdf">
      <el-button>导入报销单 PDF</el-button>
    </el-upload>
    <el-button style="margin-left:8px" @click="pdf">导出 PDF</el-button>
    <h3>进度</h3>
    <Timeline :nodes="detail.timeline || []" />
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import http, { download } from '../../api'
import Timeline from '../../components/Timeline.vue'

const route = useRoute()
const detail = ref<any>()
async function load() {
  detail.value = (await http.get(`/api/finance/claims/${route.params.id}`)).data.data
}
onMounted(load)
async function confirm(invoiceId: number) {
  await http.post(`/api/finance/claims/${route.params.id}/invoices/${invoiceId}/confirm`)
  ElMessage.success('已确认')
  await load()
}
async function importPdf(opt: any) {
  const fd = new FormData()
  fd.append('file', opt.file)
  fd.append('claimId', String(route.params.id))
  await http.post('/api/finance/pdf/import', fd)
  ElMessage.success('已导入')
}
async function pdf() {
  await download('/api/finance/pdf/export', detail.value.form.claimNo + '.pdf', { method: 'GET', params: { id: route.params.id } })
}
</script>
