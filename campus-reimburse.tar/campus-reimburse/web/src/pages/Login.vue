<template>
  <div class="login-box">
    <h2>智汇签 · 校园智能报销</h2>
    <p class="muted">一期双端：申请人 / 审批人。差旅先申请、后报销。</p>
    <el-form @submit.prevent="onSubmit" style="margin-top:16px">
      <el-form-item label="账号"><el-input v-model="username" /></el-form-item>
      <el-form-item label="密码"><el-input v-model="password" type="password" show-password /></el-form-item>
      <el-button type="primary" native-type="submit" :loading="loading" style="width:100%">登录</el-button>
    </el-form>
    <p class="muted" style="margin-top:16px">演示账号（密码均为 Campus@2026）</p>
    <div class="demo-btns">
      <el-button size="small" @click="fill('zhang')">张同学·申请</el-button>
      <el-button size="small" @click="fill('wang')">王老师·申请</el-button>
      <el-button size="small" @click="fill('li')">李主任·领导</el-button>
      <el-button size="small" @click="fill('zhou')">周院长·学院</el-button>
      <el-button size="small" @click="fill('chen')">陈会计·财务</el-button>
      <el-button size="small" @click="fill('admin')">管理员</el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useAuth } from '../stores'

const username = ref('zhang')
const password = ref('Campus@2026')
const loading = ref(false)
const router = useRouter()
const auth = useAuth()

function fill(u: string) {
  username.value = u
  password.value = 'Campus@2026'
}
async function onSubmit() {
  loading.value = true
  try {
    await auth.login(username.value, password.value)
    ElMessage.success('登录成功')
    router.push(auth.homePath())
  } catch {
    /* interceptor already shows message */
  } finally {
    loading.value = false
  }
}
</script>
