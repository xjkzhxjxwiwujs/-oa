#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
docker compose up -d --build
docker compose ps
echo "Open http://metabb.cn:18080"
echo "Demo users: zhang/wang/li/zhou/chen/admin  password Campus@2026"
