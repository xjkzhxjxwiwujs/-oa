#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
sed -i 's/\r$//' "$ROOT"/*.sh "$ROOT"/nginx.conf 2>/dev/null || true

RUNTIME="$ROOT/runtime"
LOGS="$ROOT/logs"
mkdir -p "$LOGS" "$ROOT/tmp/client_body" "$ROOT/tmp/proxy" "$ROOT/tmp/fastcgi" "$ROOT/tmp/uwsgi" "$ROOT/tmp/scgi"
set -a
# shellcheck disable=SC1091
source "$ROOT/.env"
set +a

export JAVA_HOME="$RUNTIME/jdk"
export PATH="$JAVA_HOME/bin:$PATH"
MYSQL_BASE="$RUNTIME/mysql"
MYSQL_SOCK="$RUNTIME/mysql.sock"
export LD_LIBRARY_PATH="$MYSQL_BASE/lib:${LD_LIBRARY_PATH:-}"

wait_port() {
  local port="$1" n=0
  while ! bash -c "echo >/dev/tcp/127.0.0.1/$port" 2>/dev/null; do
    n=$((n+1))
    if [[ "$n" -gt 60 ]]; then
      echo "timeout waiting for port $port"
      return 1
    fi
    sleep 1
  done
}

if [[ ! -f "$RUNTIME/mysql.pid" ]] || ! kill -0 "$(cat "$RUNTIME/mysql.pid")" 2>/dev/null; then
  "$MYSQL_BASE/bin/mysqld" --defaults-file="$RUNTIME/my.cnf" --daemonize
fi
wait_port 13306
"$MYSQL_BASE/bin/mysql" --socket="$MYSQL_SOCK" -u root -e "CREATE DATABASE IF NOT EXISTS ${MYSQL_DB} CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci; CREATE USER IF NOT EXISTS '${MYSQL_USER}'@'127.0.0.1' IDENTIFIED BY '${MYSQL_PASSWORD}'; GRANT ALL ON ${MYSQL_DB}.* TO '${MYSQL_USER}'@'127.0.0.1'; CREATE USER IF NOT EXISTS '${MYSQL_USER}'@'localhost' IDENTIFIED BY '${MYSQL_PASSWORD}'; GRANT ALL ON ${MYSQL_DB}.* TO '${MYSQL_USER}'@'localhost'; FLUSH PRIVILEGES;"

if ! bash -c "echo >/dev/tcp/127.0.0.1/16379" 2>/dev/null; then
  "$RUNTIME/redis/src/redis-server" --port 16379 --bind 127.0.0.1 --daemonize yes --dir "$RUNTIME/redis-data" --pidfile "$RUNTIME/redis.pid" --logfile "$LOGS/redis.log" --dbfilename dump.rdb
fi
wait_port 16379

if ! bash -c "echo >/dev/tcp/127.0.0.1/19000" 2>/dev/null; then
  export MINIO_ROOT_USER="${MINIO_ROOT_USER}"
  export MINIO_ROOT_PASSWORD="${MINIO_ROOT_PASSWORD}"
  nohup "$RUNTIME/minio/minio" server "$RUNTIME/minio-data" --address 127.0.0.1:19000 --console-address 127.0.0.1:19001 > "$LOGS/minio.log" 2>&1 &
  echo $! > "$RUNTIME/minio.pid"
fi
wait_port 19000

if ! bash -c "echo >/dev/tcp/127.0.0.1/18081" 2>/dev/null; then
  nohup env \
    SERVER_PORT=18081 \
    MYSQL_HOST=127.0.0.1 \
    MYSQL_PORT=13306 \
    MYSQL_DB="${MYSQL_DB}" \
    MYSQL_USER="${MYSQL_USER}" \
    MYSQL_PASSWORD="${MYSQL_PASSWORD}" \
    REDIS_HOST=127.0.0.1 \
    REDIS_PORT=16379 \
    MINIO_ENDPOINT=http://127.0.0.1:19000 \
    MINIO_ACCESS_KEY="${MINIO_ROOT_USER}" \
    MINIO_SECRET_KEY="${MINIO_ROOT_PASSWORD}" \
    CAMPUS_AES_KEY="${CAMPUS_AES_KEY}" \
    "$JAVA_HOME/bin/java" -jar "$RUNTIME/app.jar" > "$LOGS/api.log" 2>&1 &
  echo $! > "$RUNTIME/api.pid"
fi
for i in $(seq 1 60); do
  if curl -fsS "http://127.0.0.1:18081/actuator/health" >/dev/null 2>&1; then
    break
  fi
  sleep 2
  if [[ "$i" -eq 60 ]]; then
    echo "API failed to start, see logs/api.log"
    tail -n 80 "$LOGS/api.log" || true
    exit 1
  fi
done

if [[ -f "$LOGS/nginx.pid" ]] && kill -0 "$(cat "$LOGS/nginx.pid")" 2>/dev/null; then
  nginx -p "$ROOT" -c "$ROOT/nginx.conf" -s reload || true
else
  nginx -p "$ROOT" -c "$ROOT/nginx.conf"
fi

echo "Started. Open http://metabb.cn:18080"
echo "Demo: zhang/wang/li/zhou/chen/admin  password Campus@2026"
curl -fsS "http://127.0.0.1:18080/" >/dev/null && echo "web ok" || echo "web not ready"
curl -fsS "http://127.0.0.1:18081/actuator/health" && echo
